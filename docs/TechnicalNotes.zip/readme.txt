
This folder contains technical notes and some other information regarding various head types supported by Meteor PrintEngine.
These technical notes is not an official documentation and might be incomplete or out of date.

This is not a complete official documentation. Instead, technical notes focus on very specific detailed technical
information. For example, "HeadInfo" directory contains some head-specific details regarding head waveforms, 
temperatures, config parameters and so on. 

"TestApp" diretory contains notes on some TestApp features etc.

This is a good place to start reading if you have a technical question.

N.B. these notes are distributes as a single *.zip archive with the Meteor system installer.


  


