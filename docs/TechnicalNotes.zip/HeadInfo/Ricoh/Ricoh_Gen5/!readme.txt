
=================================================================================================

This directory contains technical notes that apply to a new implementation of Ricoh Gen5 head only.
Following head types supported:


    head type:      Head type name          Default config files:
                    in the config file:

    HT_RicohGen5    "Ricoh_Gen5"            Default_Ricoh_Gen5_PccZ.cfg
  
=================================================================================================

This new head type present better implementation for Ricoh Gen5 head.
This head type is currently supported only on a PCC-Z and HMB-2R5 variant. 
PccZ drives 2 HDCs (on HMB), each HDC drives 1 head.




  