
=================================================================================================

This directory contains technical notes that apply to a legacy implementation of Ricoh Gen4 and Gen5.


    head type:      Head type name          Default config files:
                    in the config file:

    HT_RG4          "RicohGen4"             DefaultRicohGen4.cfg, DefaultRicohGen4_PccE.cfg
    HT_RG5          "RicohGen5"             DefaultRicohGen5.cfg, DefaultRicohGen5_PccE.cfg
  


=================================================================================================

